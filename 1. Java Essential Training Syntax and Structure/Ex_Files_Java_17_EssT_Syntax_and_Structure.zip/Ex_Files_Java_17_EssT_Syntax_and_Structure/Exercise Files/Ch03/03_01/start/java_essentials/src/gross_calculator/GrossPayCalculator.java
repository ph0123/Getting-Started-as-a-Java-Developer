package gross_calculator;

public class GrossPayCalculator {

    public static void main(String[] args){
        //1. Get the number of hours worked

        //2. Get the hourly pay rate

        //3. Multiply hours and pay rate

        //4. Display result

    }
}
