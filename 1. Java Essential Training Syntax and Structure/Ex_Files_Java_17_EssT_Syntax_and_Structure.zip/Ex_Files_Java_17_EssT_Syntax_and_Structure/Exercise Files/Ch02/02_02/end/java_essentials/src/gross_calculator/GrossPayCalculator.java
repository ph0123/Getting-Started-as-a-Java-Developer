package gross_calculator;

public class GrossPayCalculator {
}
